﻿using ASPHomeWork2.DataAccessLayer;
using ASPHomeWork2.Models;
using ASPHomeWork2.ViewModel;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Areas.AdminPanel.Controllers
{
    public class UsersController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly AppDbContext _dbContext;

        public UsersController(UserManager<User> userManager, RoleManager<IdentityRole> roleManager, AppDbContext dbContext)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _dbContext = dbContext;
        }
        public async Task<IActionResult> Index()
        {
            var users = await _userManager.Users.ToListAsync();

            return View(users);
        }

        public IActionResult ChangePassword()
        {
           
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {

            if (!ModelState.IsValid)
                return View();
            var existUser = await _userManager.FindByNameAsync(model.Username);
            if (existUser == null)
            {
                ModelState.AddModelError("Username", "User does not exist with this username");
                return View();
            }
            if (model.NewPassword == model.ConfirmNewPassword)
            {
                ModelState.AddModelError("NewPassword", "NewPassword and ConfirmNewPassword does not match");
                return View();
            }

            var result = await _userManager.ChangePasswordAsync(existUser, model.NewPassword, model.NewPassword);

            if (!result.Succeeded)
            {
                foreach (var item in result.Errors)
                {
                    ModelState.AddModelError("", item.Description);
                }
                return View(model);
            }

            return RedirectToAction("Index");
        }


        public async Task<IActionResult> ChangeRoleAsync(string Id)
        {

            if (!ModelState.IsValid)
                return View();
            var existUser = await _userManager.FindByIdAsync(Id);
            if (existUser == null)
            {
                ModelState.AddModelError("Username", "User does not exist with this username");
                return View();
            }
            return View();

        }

        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> ChangeRoleAsync(string Id, UsersViewModel userModel)
        {

            var User = await _userManager.FindByIdAsync(Id);
            if (User == null)
                return NotFound();
            var existRolesOfUser = await _userManager.GetRolesAsync(User);
            foreach (var role in existRolesOfUser)
            {
                await _userManager.RemoveFromRoleAsync(User, role);
            }

            var newRole = _roleManager.Roles.FirstOrDefault(x => x.Name == userModel.UserRole);

            var result = await _userManager.AddToRoleAsync(User, newRole.Name);
            if (!result.Succeeded)
            {
                foreach (var item in result.Errors)
                {
                    ModelState.AddModelError("", item.Description);
                }
                return View(userModel);
            }

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> ActivateDeactivate(bool status, string Id)
        {
            var User = await _userManager.FindByIdAsync(Id);
            if (User == null)
                return NotFound();

            await _userManager.UpdateAsync(User);

            if (status==false)
                User.CurrentStatus = true;
            else
                User.CurrentStatus = false;

            return RedirectToAction(nameof(Index));
        }
    }
}
