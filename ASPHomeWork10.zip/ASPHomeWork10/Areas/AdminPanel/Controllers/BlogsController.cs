﻿using ASPHomeWork2.DataAccessLayer;
using ASPHomeWork2.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    [Authorize]
    public class BlogsController : Controller
    {
        private readonly AppDbContext _dbContext;

        public BlogsController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var Blogs = await _dbContext.Blogs.ToListAsync();

            return View(Blogs);
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return BadRequest();

            var blog = await _dbContext.Blogs.FindAsync(id);
            if (blog == null)
                return NotFound();

            return View(blog);
            
        }

        public IActionResult Create()
        {
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Blog blog)
        {
            if (!ModelState.IsValid)
                return View();

            var isExistBlog = await _dbContext.Blogs.AnyAsync(x => x.Title.ToLower() == blog.Title.ToLower());
            if (isExistBlog)
            {
                ModelState.AddModelError("Title", "Blog already exists with this title");
                return View();
            }

            await _dbContext.Blogs.AddAsync(blog);
            await _dbContext.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            Blog isExist = _dbContext.Blogs.FirstOrDefault(x => x.id == id);
                if (isExist == null)
                return Content("404 not found");

            _dbContext.Blogs.Remove(isExist);
            _dbContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();
            var blog = await _dbContext.Blogs.FindAsync(id);
            if(blog==null)
                return NotFound();

            return View(blog);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, Blog blog)
        {
            if (id == null)
                return NotFound();
            if (id != blog.id)
                return BadRequest();
            if (!ModelState.IsValid)
                return View();
            var existBlog = await _dbContext.Blogs.FindAsync(id);
            if (existBlog == null)
                return NotFound();
            var isExist=await _dbContext.Blogs.AnyAsync(x=>x.Title.ToLower()==blog.Title.ToLower() && x.id!=id);
            if(isExist)
            {
             ModelState.AddModelError("Title", "Bu adda blog artig movcuddur" );
            return View();
            }

            existBlog.Title = blog.Title;
            existBlog.Info = blog.Info;
            existBlog.Image = blog.Image;
            existBlog.Date= DateTime.UtcNow.AddHours(4);

            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
