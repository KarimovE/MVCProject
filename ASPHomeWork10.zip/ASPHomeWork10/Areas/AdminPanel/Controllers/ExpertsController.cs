﻿using ASPHomeWork2.Areas.AdminPanel.Data;
using ASPHomeWork2.DataAccessLayer;
using ASPHomeWork2.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Threading.Tasks;

namespace ASPHomeWork2.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class ExpertsController : Controller
    {
        private readonly AppDbContext _dbContext;
        private readonly IWebHostEnvironment _enviroment;
        public ExpertsController (AppDbContext dbContext, IWebHostEnvironment enviroment)
        {
            _dbContext = dbContext;
            _enviroment = enviroment; 
        }
        public async Task<IActionResult> Index()
        {
            var Experts = await _dbContext.Experts.ToListAsync();

            return View(Experts);
        }
        public IActionResult Create()
        {

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Expert expert)
        {
            if (!ModelState.IsValid)
                return View();

            var isExistExpert = await _dbContext.Experts.AnyAsync(x => x.Name.ToLower() == expert.Name.ToLower());
            if (isExistExpert)
            {
                ModelState.AddModelError("Name", "Expert already exists with this Name");
                return View();
            }

            if(!expert.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "You must upload an image");
                return View();
            }

            if (!expert.Photo.IsAllowedSize(1))
            {
                ModelState.AddModelError("Photo", "Image size must be less than 1 mb.");
                return View();
            }

            var filename = await expert.Photo.GenerateFile(Constants.ImageFolderPath);
            expert.Image = filename;
            await _dbContext.Experts.AddAsync(expert);
            await _dbContext.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();

            var expert = await _dbContext.Experts.FindAsync(id);
            if (expert == null)
                return NotFound();

            return View(expert);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, Expert expert)
        {
            if (id == null)
                return NotFound();

            if (id != expert.Id)
                return BadRequest();

           

            var existExpert = await _dbContext.Experts.FindAsync(id);
            if (existExpert == null)
                return NotFound(existExpert);

            if (!ModelState.IsValid)
                return View();


            if (!expert.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "You must upload an image");
                return View(existExpert);
            }

            if (!expert.Photo.IsAllowedSize(1))
            {
                ModelState.AddModelError("Photo", "Image size must be less than 1 mb.");
                return View(existExpert);
            }
            var path = Path.Combine(Constants.ImageFolderPath, existExpert.Image);

            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }
            var filename = await expert.Photo.GenerateFile(Constants.ImageFolderPath);

            existExpert.Image = filename;

            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return BadRequest();

            var expert = await _dbContext.Experts.FindAsync(id);
            if (expert == null)
                return NotFound();

            return View(expert);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteExpert(int? id)
        {
            if (id == null)
                return BadRequest();

            var expert = await _dbContext.Experts.FindAsync(id);
            if (expert == null)
                return NotFound();

            var path = Path.Combine(Constants.ImageFolderPath, expert.Image);

            if (System.IO.File.Exists(path))
            {
                System.IO.File.Delete(path);
            }

            _dbContext.Experts.Remove(expert);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
