﻿using System.ComponentModel.DataAnnotations;

namespace ASPHomeWork2.ViewModel
{
    public class ChangePasswordViewModel
    {
        [Required]
        public string Username { get; set; }

        [Required, DataType(DataType.Password)]
        public string NewPassword { get; set; }  
        [Required, DataType(DataType.Password)]
        public string ConfirmNewPassword { get; set; }
    }
}
