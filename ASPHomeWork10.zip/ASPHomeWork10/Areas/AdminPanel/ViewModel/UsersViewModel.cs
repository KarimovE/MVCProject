﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ASPHomeWork2.ViewModel
{
    public class UsersViewModel : IdentityUser
    {
        [Required]
        public string Username { get; set; }

        [Required, DataType(DataType.Password)]
        public string Email { get; set; }
        [Required]
        public string UserRole { get; set; }
        public bool UserStatus { get; set; }=true;


    }
}
