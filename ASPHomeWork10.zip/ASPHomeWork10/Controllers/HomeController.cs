﻿using ASPHomeWork2.DataAccessLayer;
using ASPHomeWork2.Models;
using ASPHomeWork2.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _dbContext;

        public HomeController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            Response.Cookies.Append("", "", new CookieOptions { Expires = DateTimeOffset.Now.AddHours(1) });

            var aboutSection = _dbContext.AboutSection.SingleOrDefault();
            var expertInfo = _dbContext.ExpertInfos.SingleOrDefault();
            var experts = _dbContext.Experts.ToList();
            var subscribes = _dbContext.Subscribes.SingleOrDefault();
            var sliderImages = _dbContext.SliderImages.ToList();
            var slider = _dbContext.Sliders.SingleOrDefault();
            var categories = _dbContext.Categories.ToList();
            //var products = _dbContext.Products.Include(x => x.Category).ToList();
            var blogs = _dbContext.Blogs.ToList();
            var says = _dbContext.Says.ToList();
            var instagrams = _dbContext.Instagrams.ToList();
            return View(new HomeViewModel
            {
                AboutSection = aboutSection,
                ExpertInfo = expertInfo,
                Experts = experts,
                Subscribes = subscribes,
                SliderImages = sliderImages,
                Slider = slider,
                Categories = categories,
                Blogs=blogs,
                Says=says,
                Instagrams= instagrams
                //Products = products
            }) ;
        }

       

        public async Task<IActionResult> AddToBasket(int? id)
        {
            if (id == null)
                return BadRequest();

            var product = await _dbContext.Products.FindAsync(id);
            if (product == null)
                return NotFound();

            List<BasketViewModel> basketViewModels;
            var existBasket = Request.Cookies["basket"];
            
            if (string.IsNullOrEmpty(existBasket))
            {
                basketViewModels = new List<BasketViewModel>();
            }
            else
            {
                basketViewModels = JsonConvert.DeserializeObject<List<BasketViewModel>>(existBasket);
            }

            var existBasketViewModel = basketViewModels.FirstOrDefault(x => x.Id == id);
            if (existBasketViewModel==null)
            {
                existBasketViewModel = new BasketViewModel
                {
                    Id = product.Id,

                };
                basketViewModels.Add(existBasketViewModel);
            }
            else
            {
                existBasketViewModel.Count++;
            }

            var basket = JsonConvert.SerializeObject(basketViewModels);
            Response.Cookies.Append("basket", basket);

            return Json(basketViewModels);
        }
    }
}
