﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace ASPHomeWork2.Models
{
    public class User : IdentityUser
    {   [Required]
        public string FullName { get; set; }

        [Required]
        public bool CurrentStatus { get; set; } = true;
    }
}
