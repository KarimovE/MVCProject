﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Models
{
    public class About
    {
        public int id { get; set; }

        public string  Image { get; set; }

        public string Icon { get; set; }

        public string Title { get; set; }

        public string Subtitle { get; set; }

        public string HeartList { get; set; }
    }
}
