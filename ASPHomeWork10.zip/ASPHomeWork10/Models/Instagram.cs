using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Models
{
    public class Instagram
    {
        public int Id { get; set; }
        public string Image { get; set; }
    }
}