using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
namespace ASPHomeWork2.Models
{
    public class Blog
    {
        public int id { get; set; }
        [MaxLength(200, ErrorMessage = "Length limit to be considred")]
        public string Info { get; set; }

        public DateTime Date { get; set; } = DateTime.UtcNow.AddHours(4);
        public string Image { get; set; }
        [Required(ErrorMessage ="This input must be filled"), MaxLength(50)]
        public string Title { get; set; }
    }
}