﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPHomeWork2.Models
{
    public class ExpertInfo
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Subtitle { get; set; }
    }
}
