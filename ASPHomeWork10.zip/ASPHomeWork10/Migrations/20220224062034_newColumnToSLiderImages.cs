﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ASPHomeWork2.Migrations
{
    public partial class newColumnToSLiderImages : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
