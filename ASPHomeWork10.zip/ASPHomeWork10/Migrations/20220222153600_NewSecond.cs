﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ASPHomeWork2.Migrations
{
    public partial class NewSecond : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpertInfoId",
                table: "Experts");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ExpertInfoId",
                table: "Experts",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
