﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ASPHomeWork2.Migrations
{
    public partial class Neww : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Experts_ExpertInfos_ExpertInfoId",
                table: "Experts");

            migrationBuilder.DropIndex(
                name: "IX_Experts_ExpertInfoId",
                table: "Experts");

            migrationBuilder.AlterColumn<int>(
                name: "ExpertInfoId",
                table: "Experts",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "ExpertInfoId",
                table: "Experts",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Experts_ExpertInfoId",
                table: "Experts",
                column: "ExpertInfoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Experts_ExpertInfos_ExpertInfoId",
                table: "Experts",
                column: "ExpertInfoId",
                principalTable: "ExpertInfos",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
