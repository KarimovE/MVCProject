﻿using Microsoft.AspNetCore.Identity;

namespace ASPHomeWork2.Data
{
    public class IdentityErrors : IdentityErrorDescriber
    {
        public override IdentityError DuplicateEmail(string email)
        {
            return new IdentityError
            {
                Code = "Email",
                Description = "This email has already been used."

            };
        }
    }
}
